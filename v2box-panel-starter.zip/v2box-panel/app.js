const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const toast = (message) => {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(window.toastTimer); window.toastTimer = setTimeout(() => el.classList.remove("show"), 2300);
};
$("#today").textContent = new Intl.DateTimeFormat("fa-IR", {year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());

$$(".nav-item").forEach(btn => btn.addEventListener("click", () => {
  $$(".nav-item").forEach(b => b.classList.toggle("active", b === btn));
  $("#pageTitle").textContent = btn.dataset.page;
  if (btn.dataset.page !== "داشبورد") toast(`بخش «${btn.dataset.page}» در نسخه نمایشی آماده توسعه است.`);
  if (window.innerWidth <= 700) $(".sidebar").classList.remove("open");
}));
$$("[data-page]").filter(el => !el.classList.contains("nav-item")).forEach(btn => btn.addEventListener("click", () => {
  const target = $(`.nav-item[data-page="${btn.dataset.page}"]`);
  if (target) target.click();
}));
$("#menuBtn").addEventListener("click", () => $(".sidebar").classList.toggle("open"));
$("#themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
  $("#themeBtn").textContent = document.body.classList.contains("light") ? "☾" : "☼";
});
$("#connectionBtn").addEventListener("click", () => {
  $("#connectionMsg").textContent = "رابط کاربری با موفقیت اجرا شده؛ این بررسی اتصال واقعی سرور نیست.";
});
$("#rangeSelect").addEventListener("change", e => {
  toast(`بازه «${e.target.value}» انتخاب شد؛ داده‌ها همچنان نمونه هستند.`);
});
$$(".copy-btn").forEach(btn => btn.addEventListener("click", async () => {
  const value = btn.dataset.copy;
  try { await navigator.clipboard.writeText(value); toast("رشته نمونه کپی شد."); }
  catch { toast(`نمونه: ${value}`); }
}));
$("#searchInput").addEventListener("input", e => {
  const query = e.target.value.trim().toLowerCase();
  let count = 0;
  $$("#usersTable tbody tr, #configsTable tbody tr").forEach(row => {
    const match = row.textContent.toLowerCase().includes(query);
    row.hidden = !!query && !match; if (match) count++;
  });
  if (query) $("#pageTitle").textContent = `نتایج جستجو (${count})`;
  else $("#pageTitle").textContent = "داشبورد";
});

// Draw a lightweight illustrative chart; no external chart library required.
function drawChart() {
  const canvas = $("#trafficChart"), rect = canvas.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, rect.width * ratio); canvas.height = Math.max(1, rect.height * ratio);
  const ctx = canvas.getContext("2d"); ctx.scale(ratio, ratio);
  const w = rect.width, h = rect.height;
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle = "rgba(90,125,175,.17)"; ctx.lineWidth = 1;
  for(let i=0;i<=6;i++){const y=i*h/6;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  for(let i=0;i<=7;i++){const x=i*w/7;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
  const down=[.72,.56,.61,.38,.18,.53,.68,.79,.27,.54,.66];
  const up=[.88,.82,.78,.81,.59,.74,.86,.89,.61,.73,.81];
  function line(data,color,fill){
    const pts=data.map((v,i)=>({x:i*w/(data.length-1),y:v*h}));
    ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
    ctx.strokeStyle=color;ctx.lineWidth=2.5;ctx.stroke();
    if(fill){ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,fill);g.addColorStop(1,"rgba(30,100,255,0)");ctx.fillStyle=g;ctx.fill();}
    pts.forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,2.5,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();});
  }
  line(up,"#8d43f4","rgba(141,67,244,.16)");line(down,"#2585ff","rgba(37,133,255,.20)");
}
window.addEventListener("resize", drawChart);
requestAnimationFrame(drawChart);
